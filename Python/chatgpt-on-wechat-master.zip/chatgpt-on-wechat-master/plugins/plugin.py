class Plugin:
    def __init__(self):
        self.handlers = {}

    def get_help_text(self, **kwargs):
        return "暂无帮助信息"
